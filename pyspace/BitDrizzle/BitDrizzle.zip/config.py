host = "127.0.0.1"
base_peer_port = 40000
base_local_port = 50000
search_for_open_port = True
net_size = 8
data_file = 'test_file.txt'
test_key = "701e84d7042f08f09631137ec9f66647"
piece_size = 512
